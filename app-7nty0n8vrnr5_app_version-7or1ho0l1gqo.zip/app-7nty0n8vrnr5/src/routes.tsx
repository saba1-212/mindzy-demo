import LandingPage from './pages/LandingPage';
import Dashboard from './pages/Dashboard';
import StudyPlanner from './pages/StudyPlanner';
import ResourceFinder from './pages/ResourceFinder';
import Timer from './pages/Timer';
import ChatBoard from './pages/ChatBoard';
import Analytics from './pages/Analytics';
import TodoList from './pages/TodoList';
import QuickNotes from './pages/QuickNotes';
import FlowchartMaker from './pages/FlowchartMaker';
import SlideMaker from './pages/SlideMaker';
import StudyRoom from './pages/StudyRoom';
import QuizGenerator from './pages/QuizGenerator';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Landing Page',
    path: '/',
    element: <LandingPage />
  },
  {
    name: 'Dashboard',
    path: '/dashboard',
    element: <Dashboard />
  },
  {
    name: 'Study Planner',
    path: '/study-planner',
    element: <StudyPlanner />
  },
  {
    name: 'Resource Finder',
    path: '/resource-finder',
    element: <ResourceFinder />
  },
  {
    name: 'Timer',
    path: '/timer',
    element: <Timer />
  },
  {
    name: 'Chat Board',
    path: '/chat-board',
    element: <ChatBoard />
  },
  {
    name: 'Analytics',
    path: '/analytics',
    element: <Analytics />
  },
  {
    name: 'To-Do List',
    path: '/todo-list',
    element: <TodoList />
  },
  {
    name: 'Quick Notes',
    path: '/quick-notes',
    element: <QuickNotes />
  },
  {
    name: 'Flowchart Maker',
    path: '/flowchart-maker',
    element: <FlowchartMaker />
  },
  {
    name: 'Slide Maker',
    path: '/slide-maker',
    element: <SlideMaker />
  },
  {
    name: 'Study Room',
    path: '/study-room',
    element: <StudyRoom />
  },
  {
    name: 'Quiz Generator',
    path: '/quiz-generator',
    element: <QuizGenerator />
  }
];

export default routes;