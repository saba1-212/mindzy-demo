import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import {
  Calendar,
  Search,
  Clock,
  MessageSquare,
  BarChart3,
  CheckSquare,
  StickyNote,
  GitBranch,
  Presentation,
  Video,
  FileQuestion,
  Menu,
  X,
} from 'lucide-react';

export default function Dashboard() {
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const modules = [
    { icon: Calendar, title: 'Study Planner', path: '/study-planner', description: 'AI-powered timetable generation' },
    { icon: Search, title: 'Resource Finder', path: '/resource-finder', description: 'Curated learning materials' },
    { icon: Clock, title: 'Timer', path: '/timer', description: 'Focus and productivity timer' },
    { icon: MessageSquare, title: 'Chat Board', path: '/chat-board', description: 'Collaborate with peers' },
    { icon: BarChart3, title: 'Analytics', path: '/analytics', description: 'Track your progress' },
    { icon: CheckSquare, title: 'To-Do List', path: '/todo-list', description: 'Manage your tasks' },
    { icon: StickyNote, title: 'Quick Notes', path: '/quick-notes', description: 'Capture ideas instantly' },
    { icon: GitBranch, title: 'Flowchart Maker', path: '/flowchart-maker', description: 'Visual mind mapping' },
    { icon: Presentation, title: 'Slide Maker', path: '/slide-maker', description: 'Create presentations' },
    { icon: Video, title: 'Study Room', path: '/study-room', description: 'Virtual study sessions' },
    { icon: FileQuestion, title: 'Quiz Generator', path: '/quiz-generator', description: 'Test your knowledge' },
  ];

  return (
    <div className="flex min-h-screen bg-background relative overflow-hidden">
      {/* Floating Blobs Background */}
      <div className="floating-blob w-96 h-96 bg-primary/10 top-20 left-10 fixed"></div>
      <div className="floating-blob w-80 h-80 bg-secondary/8 bottom-20 right-20 fixed" style={{ animationDelay: '5s' }}></div>
      <div className="floating-blob w-72 h-72 bg-accent/6 top-1/2 left-1/3 fixed" style={{ animationDelay: '10s' }}></div>

      {/* Sidebar */}
      <aside
        className={`fixed xl:static inset-y-0 left-0 z-50 w-64 bg-[#0f1419] border-r border-primary/20 transition-all duration-300 shadow-2xl ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full xl:translate-x-0'
        }`}
      >
        <div className="flex flex-col h-full">
          <div className="p-6 border-b border-primary/20">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl font-bold text-white">MINDZY</h1>
              <Button
                variant="ghost"
                size="icon"
                className="xl:hidden text-white hover:bg-primary/20"
                onClick={() => setSidebarOpen(false)}
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
            <p className="text-sm text-white/60 mt-1">Student Productivity</p>
          </div>

          <nav className="flex-1 overflow-y-auto p-4">
            <div className="space-y-2">
              {modules.map((module, index) => {
                const Icon = module.icon;
                return (
                  <Button
                    key={index}
                    variant="ghost"
                    className="w-full justify-start gap-3 text-white hover:bg-primary/20 hover:shadow-lg hover:shadow-primary/30 transition-all duration-300 group"
                    onClick={() => navigate(module.path)}
                  >
                    <Icon className="w-5 h-5 text-[#6CB6FF] group-hover:text-[#8FCDFF] group-hover:drop-shadow-[0_0_8px_rgba(108,182,255,0.6)] transition-all duration-300" />
                    <span className="group-hover:text-white/90 transition-colors duration-300">{module.title}</span>
                  </Button>
                );
              })}
            </div>
          </nav>

          <div className="p-4 border-t border-primary/20">
            <Button
              variant="outline"
              className="w-full text-white border-primary/30 hover:bg-primary/20 hover:border-primary/50 transition-all duration-300"
              onClick={() => navigate('/')}
            >
              Back to Home
            </Button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 relative z-10">
        {/* Header */}
        <header className="sticky top-0 z-40 bg-card/80 backdrop-blur-xl border-b border-border shadow-lg">
          <div className="flex items-center justify-between p-4 xl:p-6">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                className="xl:hidden hover:bg-primary/10"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="w-5 h-5" />
              </Button>
              <div className="slide-in">
                <h2 className="text-2xl xl:text-3xl font-bold text-glow">Welcome to MINDZY</h2>
                <p className="text-sm text-muted-foreground">Choose a module to get started</p>
              </div>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="p-4 xl:p-8">
          <div className="max-w-7xl mx-auto">
            {/* Welcome Section */}
            <div className="mb-12 text-center fade-in">
              <h3 className="text-3xl xl:text-4xl font-bold mb-4 text-foreground">
                Your Productivity Hub
              </h3>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Select any module below to enhance your learning experience with AI-powered tools
              </p>
            </div>

            {/* Module Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 xl:gap-8">
              {modules.map((module, index) => {
                const Icon = module.icon;
                return (
                  <div
                    key={index}
                    className="dashboard-card glassmorphism p-8 rounded-3xl cursor-pointer group hover:shadow-2xl transition-all duration-500"
                    style={{ animationDelay: `${index * 0.1}s` }}
                    onClick={() => navigate(module.path)}
                  >
                    <div className="flex flex-col items-center text-center">
                      <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary/20 to-secondary/10 flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-3 transition-all duration-300 shadow-lg">
                        <Icon className="w-10 h-10 text-primary icon-pulse drop-shadow-lg" strokeWidth={1.5} />
                      </div>
                      <h3 className="text-2xl font-bold mb-3 text-foreground group-hover:text-primary transition-colors duration-300">
                        {module.title}
                      </h3>
                      <p className="text-muted-foreground leading-relaxed">
                        {module.description}
                      </p>
                    </div>
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-3xl"></div>
                  </div>
                );
              })}
            </div>

            {/* Bottom Section */}
            <div className="mt-16 text-center fade-in">
              <div className="inline-block p-8 glassmorphism rounded-3xl">
                <h4 className="text-2xl font-bold mb-3 text-foreground">Need Help?</h4>
                <p className="text-muted-foreground mb-6">
                  Explore our tools and boost your productivity today
                </p>
                <Button
                  size="lg"
                  className="btn-glow px-8 py-6 rounded-full font-bold"
                  onClick={() => navigate('/')}
                >
                  Learn More
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Overlay for mobile sidebar */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 xl:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}
