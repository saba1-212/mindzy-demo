import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, Plus, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Note {
  id: number;
  content: string;
  color: string;
}

export default function QuickNotes() {
  const navigate = useNavigate();
  const [notes, setNotes] = useState<Note[]>([
    { id: 1, content: 'Remember to review chapter 5 before the exam', color: 'bg-primary/20' },
    { id: 2, content: 'Key formula: E = mc²', color: 'bg-secondary/20' },
    { id: 3, content: 'Study group meeting on Friday at 3 PM', color: 'bg-accent/20' },
  ]);
  const [isAdding, setIsAdding] = useState(false);
  const [newNoteContent, setNewNoteContent] = useState('');

  const colors = [
    'bg-primary/20',
    'bg-secondary/20',
    'bg-accent/20',
    'bg-chart-1/20',
    'bg-chart-2/20',
    'bg-chart-3/20',
  ];

  const handleAdd = () => {
    if (!newNoteContent.trim()) return;
    const note: Note = {
      id: Date.now(),
      content: newNoteContent,
      color: colors[Math.floor(Math.random() * colors.length)],
    };
    setNotes([...notes, note]);
    setNewNoteContent('');
    setIsAdding(false);
  };

  const handleDelete = (id: number) => {
    setNotes(notes.filter((note) => note.id !== id));
  };

  const handleUpdate = (id: number, content: string) => {
    setNotes(notes.map((note) => (note.id === id ? { ...note, content } : note)));
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 bg-card/95 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl font-bold">Quick Notes</h1>
              <p className="text-sm text-muted-foreground">Capture your thoughts instantly</p>
            </div>
            <Button onClick={() => setIsAdding(true)} className="btn-glow">
              <Plus className="w-5 h-5 mr-2" />
              New Note
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {isAdding && (
              <Card className="card-3d zoom-in bg-muted/30">
                <CardContent className="pt-6">
                  <Textarea
                    placeholder="Write your note here..."
                    value={newNoteContent}
                    onChange={(e) => setNewNoteContent(e.target.value)}
                    className="min-h-32 mb-4 resize-none"
                    autoFocus
                  />
                  <div className="flex gap-2">
                    <Button onClick={handleAdd} className="flex-1">
                      Save
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setIsAdding(false);
                        setNewNoteContent('');
                      }}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {notes.map((note, index) => (
              <Card
                key={note.id}
                className={`card-3d zoom-in ${note.color} group relative`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="pt-6">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDelete(note.id)}
                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                  <Textarea
                    value={note.content}
                    onChange={(e) => handleUpdate(note.id, e.target.value)}
                    className="min-h-32 resize-none bg-transparent border-none focus-visible:ring-0 focus-visible:ring-offset-0"
                  />
                </CardContent>
              </Card>
            ))}
          </div>

          {notes.length === 0 && !isAdding && (
            <div className="text-center py-16 fade-in">
              <div className="text-6xl mb-4">📝</div>
              <h3 className="text-2xl font-semibold mb-2">No notes yet</h3>
              <p className="text-muted-foreground mb-6">
                Click "New Note" to create your first quick note
              </p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
