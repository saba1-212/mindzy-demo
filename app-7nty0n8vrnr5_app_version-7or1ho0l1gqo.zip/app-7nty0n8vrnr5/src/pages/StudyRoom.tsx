import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Video, Mic, MicOff, VideoOff, Users } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function StudyRoom() {
  const navigate = useNavigate();
  const [isInRoom, setIsInRoom] = useState(false);
  const [roomName, setRoomName] = useState('');
  const [isMicOn, setIsMicOn] = useState(true);
  const [isVideoOn, setIsVideoOn] = useState(true);

  const participants = [
    { id: 1, name: 'You', avatar: '👤' },
    { id: 2, name: 'Alex', avatar: '👨' },
    { id: 3, name: 'Sarah', avatar: '👩' },
    { id: 4, name: 'Mike', avatar: '👨‍🦱' },
  ];

  const handleJoinRoom = () => {
    if (roomName.trim()) {
      setIsInRoom(true);
    }
  };

  const handleCreateRoom = () => {
    setRoomName('Study Room ' + Math.floor(Math.random() * 1000));
    setIsInRoom(true);
  };

  const handleLeaveRoom = () => {
    setIsInRoom(false);
    setRoomName('');
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 bg-card/95 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Study Room</h1>
              <p className="text-sm text-muted-foreground">Collaborate with study partners</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {!isInRoom ? (
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <Card className="card-3d fade-in">
                <CardHeader>
                  <CardTitle>Join a Room</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Input
                    placeholder="Enter room name or code"
                    value={roomName}
                    onChange={(e) => setRoomName(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleJoinRoom()}
                  />
                  <Button onClick={handleJoinRoom} className="w-full btn-glow">
                    Join Room
                  </Button>
                </CardContent>
              </Card>

              <Card className="card-3d fade-in" style={{ animationDelay: '0.1s' }}>
                <CardHeader>
                  <CardTitle>Create a Room</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">
                    Start a new study room and invite your friends to join
                  </p>
                  <Button onClick={handleCreateRoom} className="w-full btn-glow">
                    Create New Room
                  </Button>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="space-y-6">
              <Card className="card-3d fade-in">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <Users className="w-5 h-5" />
                      {roomName}
                    </CardTitle>
                    <Button variant="destructive" onClick={handleLeaveRoom}>
                      Leave Room
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 mb-6">
                    {participants.map((participant, index) => (
                      <div
                        key={participant.id}
                        className="zoom-in aspect-video bg-muted rounded-lg flex flex-col items-center justify-center relative overflow-hidden"
                        style={{ animationDelay: `${index * 0.1}s` }}
                      >
                        <div className="text-6xl mb-2">{participant.avatar}</div>
                        <div className="text-lg font-semibold">{participant.name}</div>
                        {participant.id === 1 && !isVideoOn && (
                          <div className="absolute inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center">
                            <VideoOff className="w-12 h-12 text-muted-foreground" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-center gap-4">
                    <Button
                      variant={isMicOn ? 'default' : 'destructive'}
                      size="lg"
                      onClick={() => setIsMicOn(!isMicOn)}
                      className="w-16 h-16 rounded-full"
                    >
                      {isMicOn ? <Mic className="w-6 h-6" /> : <MicOff className="w-6 h-6" />}
                    </Button>
                    <Button
                      variant={isVideoOn ? 'default' : 'destructive'}
                      size="lg"
                      onClick={() => setIsVideoOn(!isVideoOn)}
                      className="w-16 h-16 rounded-full"
                    >
                      {isVideoOn ? <Video className="w-6 h-6" /> : <VideoOff className="w-6 h-6" />}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="card-3d fade-in" style={{ animationDelay: '0.4s' }}>
                <CardHeader>
                  <CardTitle>Room Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
                    <div className="p-4 rounded-lg bg-muted/50">
                      <div className="text-sm text-muted-foreground mb-1">Room Code</div>
                      <div className="font-mono font-semibold">{roomName.replace(/\s/g, '-').toUpperCase()}</div>
                    </div>
                    <div className="p-4 rounded-lg bg-muted/50">
                      <div className="text-sm text-muted-foreground mb-1">Participants</div>
                      <div className="font-semibold">{participants.length} members</div>
                    </div>
                    <div className="p-4 rounded-lg bg-muted/50">
                      <div className="text-sm text-muted-foreground mb-1">Status</div>
                      <div className="font-semibold text-primary">Active</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
