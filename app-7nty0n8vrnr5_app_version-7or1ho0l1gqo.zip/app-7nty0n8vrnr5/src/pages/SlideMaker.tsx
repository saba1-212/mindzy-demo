import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, Plus, ChevronLeft, ChevronRight, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Slide {
  id: number;
  title: string;
  content: string;
  imageUrl: string;
}

export default function SlideMaker() {
  const navigate = useNavigate();
  const [slides, setSlides] = useState<Slide[]>([
    {
      id: 1,
      title: 'Welcome to MINDZY',
      content: 'Your ultimate student productivity platform',
      imageUrl: '',
    },
    {
      id: 2,
      title: 'Study Smarter',
      content: 'Use AI-powered tools to enhance your learning efficiency',
      imageUrl: '',
    },
    {
      id: 3,
      title: 'Stay Organized',
      content: 'Track your progress and manage your time effectively',
      imageUrl: '',
    },
  ]);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isEditing, setIsEditing] = useState(false);

  const handleAddSlide = () => {
    const newSlide: Slide = {
      id: Date.now(),
      title: 'New Slide',
      content: 'Add your content here',
      imageUrl: '',
    };
    setSlides([...slides, newSlide]);
    setCurrentSlide(slides.length);
  };

  const handleDeleteSlide = () => {
    if (slides.length === 1) return;
    const newSlides = slides.filter((_, index) => index !== currentSlide);
    setSlides(newSlides);
    setCurrentSlide(Math.max(0, currentSlide - 1));
  };

  const handleUpdateSlide = (field: keyof Slide, value: string) => {
    setSlides(
      slides.map((slide, index) =>
        index === currentSlide ? { ...slide, [field]: value } : slide
      )
    );
  };

  const handlePrevious = () => {
    setCurrentSlide(Math.max(0, currentSlide - 1));
  };

  const handleNext = () => {
    setCurrentSlide(Math.min(slides.length - 1, currentSlide + 1));
  };

  const slide = slides[currentSlide];

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 bg-card/95 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl font-bold">Slide Maker</h1>
              <p className="text-sm text-muted-foreground">Create beautiful presentations</p>
            </div>
            <Button onClick={() => setIsEditing(!isEditing)} variant="outline">
              {isEditing ? 'Preview Mode' : 'Edit Mode'}
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-5xl mx-auto">
          <Card className="card-3d fade-in mb-6">
            <CardContent className="pt-6">
              <div className="aspect-video bg-gradient-bg rounded-lg p-8 xl:p-12 flex flex-col items-center justify-center text-center relative overflow-hidden">
                {isEditing ? (
                  <div className="w-full space-y-6 z-10">
                    <Input
                      value={slide.title}
                      onChange={(e) => handleUpdateSlide('title', e.target.value)}
                      className="text-3xl xl:text-5xl font-bold text-center bg-card/80 backdrop-blur-sm"
                      placeholder="Slide Title"
                    />
                    <Textarea
                      value={slide.content}
                      onChange={(e) => handleUpdateSlide('content', e.target.value)}
                      className="text-lg xl:text-xl text-center bg-card/80 backdrop-blur-sm min-h-24 resize-none"
                      placeholder="Slide Content"
                    />
                    <Input
                      value={slide.imageUrl}
                      onChange={(e) => handleUpdateSlide('imageUrl', e.target.value)}
                      className="bg-card/80 backdrop-blur-sm"
                      placeholder="Image URL (optional)"
                    />
                  </div>
                ) : (
                  <div className="z-10">
                    <h2 className="text-4xl xl:text-6xl font-bold mb-6 text-white drop-shadow-lg">
                      {slide.title}
                    </h2>
                    <p className="text-xl xl:text-2xl text-white/90 drop-shadow-md">
                      {slide.content}
                    </p>
                    {slide.imageUrl && (
                      <img
                        src={slide.imageUrl}
                        alt="Slide"
                        className="mt-6 max-h-48 mx-auto rounded-lg"
                      />
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <div className="flex items-center justify-between mb-6">
            <Button
              variant="outline"
              onClick={handlePrevious}
              disabled={currentSlide === 0}
            >
              <ChevronLeft className="w-5 h-5 mr-2" />
              Previous
            </Button>

            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground">
                Slide {currentSlide + 1} of {slides.length}
              </span>
              <Button onClick={handleAddSlide} variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                Add Slide
              </Button>
              {slides.length > 1 && (
                <Button onClick={handleDeleteSlide} variant="outline">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
              )}
            </div>

            <Button
              variant="outline"
              onClick={handleNext}
              disabled={currentSlide === slides.length - 1}
            >
              Next
              <ChevronRight className="w-5 h-5 ml-2" />
            </Button>
          </div>

          <div className="grid grid-cols-3 xl:grid-cols-6 gap-4">
            {slides.map((s, index) => (
              <div
                key={s.id}
                className={`zoom-in cursor-pointer rounded-lg overflow-hidden border-2 transition-all ${
                  index === currentSlide ? 'border-primary' : 'border-border'
                }`}
                style={{ animationDelay: `${index * 0.05}s` }}
                onClick={() => setCurrentSlide(index)}
              >
                <div className="aspect-video bg-gradient-bg p-2 flex items-center justify-center">
                  <div className="text-xs text-white text-center font-semibold">
                    {s.title}
                  </div>
                </div>
                <div className="bg-card p-1 text-center text-xs text-muted-foreground">
                  {index + 1}
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
