import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, TrendingUp, Clock, Target, Award } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Analytics() {
  const navigate = useNavigate();

  const stats = [
    { icon: Clock, label: 'Study Hours', value: '42.5', unit: 'hours', color: 'text-primary', bgColor: 'bg-primary/10' },
    { icon: Target, label: 'Goals Completed', value: '18', unit: 'goals', color: 'text-secondary', bgColor: 'bg-secondary/10' },
    { icon: TrendingUp, label: 'Productivity', value: '87', unit: '%', color: 'text-accent', bgColor: 'bg-accent/10' },
    { icon: Award, label: 'Streak Days', value: '12', unit: 'days', color: 'text-chart-1', bgColor: 'bg-chart-1/10' },
  ];

  const subjects = [
    { name: 'Mathematics', progress: 85, color: 'bg-primary' },
    { name: 'Physics', progress: 72, color: 'bg-secondary' },
    { name: 'Chemistry', progress: 68, color: 'bg-accent' },
    { name: 'English', progress: 90, color: 'bg-chart-1' },
    { name: 'History', progress: 78, color: 'bg-chart-2' },
  ];

  const weeklyActivity = [
    { day: 'Mon', hours: 6 },
    { day: 'Tue', hours: 8 },
    { day: 'Wed', hours: 5 },
    { day: 'Thu', hours: 7 },
    { day: 'Fri', hours: 6 },
    { day: 'Sat', hours: 4 },
    { day: 'Sun', hours: 6.5 },
  ];

  const maxHours = Math.max(...weeklyActivity.map((d) => d.hours));

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 bg-card/95 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Analytics Dashboard</h1>
              <p className="text-sm text-muted-foreground">Track your study progress</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto space-y-6">
          <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Card key={index} className="card-3d zoom-in" style={{ animationDelay: `${index * 0.1}s` }}>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-lg ${stat.bgColor} flex items-center justify-center`}>
                        <Icon className={`w-6 h-6 ${stat.color}`} />
                      </div>
                      <div>
                        <div className="text-2xl font-bold">
                          {stat.value}
                          <span className="text-sm text-muted-foreground ml-1">{stat.unit}</span>
                        </div>
                        <div className="text-sm text-muted-foreground">{stat.label}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <Card className="card-3d fade-in" style={{ animationDelay: '0.4s' }}>
              <CardHeader>
                <CardTitle>Subject Progress</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {subjects.map((subject, index) => (
                  <div key={index} className="slide-in" style={{ animationDelay: `${(index + 4) * 0.1}s` }}>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">{subject.name}</span>
                      <span className="text-muted-foreground">{subject.progress}%</span>
                    </div>
                    <div className="h-3 bg-muted rounded-full overflow-hidden">
                      <div
                        className={`h-full ${subject.color} transition-all duration-1000`}
                        style={{ width: `${subject.progress}%` }}
                      />
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="card-3d fade-in" style={{ animationDelay: '0.5s' }}>
              <CardHeader>
                <CardTitle>Weekly Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end justify-between gap-2 h-48">
                  {weeklyActivity.map((day, index) => {
                    const height = (day.hours / maxHours) * 100;
                    return (
                      <div key={index} className="flex-1 flex flex-col items-center gap-2">
                        <div className="relative w-full flex-1 flex items-end">
                          <div
                            className="zoom-in w-full bg-primary rounded-t-lg transition-all duration-1000 hover:bg-primary/80 cursor-pointer"
                            style={{
                              height: `${height}%`,
                              animationDelay: `${(index + 9) * 0.1}s`,
                            }}
                            title={`${day.hours} hours`}
                          />
                        </div>
                        <span className="text-sm text-muted-foreground">{day.day}</span>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="card-3d fade-in" style={{ animationDelay: '0.6s' }}>
            <CardHeader>
              <CardTitle>Recent Achievements</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
                {[
                  { title: 'Week Warrior', description: 'Studied 7 days in a row', icon: '🔥' },
                  { title: 'Math Master', description: 'Completed 50 math problems', icon: '🎯' },
                  { title: 'Early Bird', description: 'Started studying before 8 AM', icon: '🌅' },
                ].map((achievement, index) => (
                  <div
                    key={index}
                    className="zoom-in p-4 rounded-lg bg-muted/50 border border-border"
                    style={{ animationDelay: `${(index + 16) * 0.1}s` }}
                  >
                    <div className="text-3xl mb-2">{achievement.icon}</div>
                    <h4 className="font-semibold mb-1">{achievement.title}</h4>
                    <p className="text-sm text-muted-foreground">{achievement.description}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
