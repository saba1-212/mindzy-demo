import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { Sparkles, BookOpen, Clock, Users, Brain, Zap, BookMarked, Calendar, Lightbulb, Target, Rocket, Wand2, TrendingUp, X } from 'lucide-react';
import { useEffect, useState } from 'react';

export default function LandingPage() {
  const navigate = useNavigate();
  const [expandedCard, setExpandedCard] = useState<number | null>(null);

  const features = [
    { icon: Brain, title: 'AI Study Planner', description: 'Smart timetable generation' },
    { icon: BookOpen, title: 'Resource Finder', description: 'Curated learning materials' },
    { icon: Clock, title: 'Focus Timer', description: 'Stay productive' },
    { icon: Users, title: 'Study Rooms', description: 'Collaborate with peers' },
    { icon: Zap, title: 'Quick Tools', description: 'Notes, flowcharts & more' },
    { icon: Sparkles, title: 'Smart Analytics', description: 'Track your progress' },
  ];

  const steps = [
    {
      icon: Target,
      title: 'Choose Your Module',
      description: 'Start with Study Planner, Resource Finder, Flowcharts, or Notes.',
      detailedDescription: 'You can start with Study Planner, Resource Finder, Flowcharts, Notes, and many more modules. Each module is designed to help you organize your learning journey efficiently.',
      exampleText: 'Select from 11 powerful productivity tools tailored for students.',
      image: 'https://miaoda-site-img.s3cdn.medo.dev/images/9060a453-6e5d-4b49-9581-a75606acdd71.jpg',
    },
    {
      icon: BookMarked,
      title: 'Enter Your Details',
      description: 'Add topics, study hours, questions, or tasks.',
      detailedDescription: 'Input your study topics, available hours, specific questions, or tasks you need to complete. The more details you provide, the better MINDZY can assist you.',
      exampleText: 'Simply fill in your study requirements and let AI do the rest.',
      image: 'https://miaoda-site-img.s3cdn.medo.dev/images/6c34dc75-d1f1-4d22-a419-9e9979b8f360.jpg',
    },
    {
      icon: Wand2,
      title: 'AI Generates Outputs',
      description: 'Timetables, resources, quizzes, flowcharts, or summaries.',
      detailedDescription: 'Our AI instantly generates personalized timetables, curated resources, practice quizzes, visual flowcharts, or study summaries based on your inputs.',
      exampleText: 'Get instant, customized study materials powered by AI.',
      image: 'https://miaoda-site-img.s3cdn.medo.dev/images/e6ebf1a4-e8a1-4ccf-887e-0b4508e1b12f.jpg',
    },
    {
      icon: TrendingUp,
      title: 'Start Your Productivity Journey',
      description: 'Track progress, collaborate, and stay organized.',
      detailedDescription: 'Monitor your study progress with analytics, collaborate with peers in study rooms, and keep everything organized with our comprehensive dashboard.',
      exampleText: 'Stay on track and achieve your academic goals with ease.',
      image: 'https://miaoda-site-img.s3cdn.medo.dev/images/9060a453-6e5d-4b49-9581-a75606acdd71.jpg',
    },
  ];

  const floatingGraphics = [
    { icon: BookMarked, delay: '0s', position: 'top-32 left-16 xl:left-32' },
    { icon: Calendar, delay: '1.5s', position: 'top-48 right-16 xl:right-32' },
    { icon: Lightbulb, delay: '0.8s', position: 'bottom-48 left-20 xl:left-40' },
  ];

  useEffect(() => {
    const revealOnScroll = () => {
      const cards = document.querySelectorAll('.card-scroll');
      cards.forEach((card, index) => {
        const rect = card.getBoundingClientRect();
        if (rect.top < window.innerHeight - 100) {
          setTimeout(() => {
            card.classList.add('visible');
          }, index * 100);
        }
      });

      const sections = document.querySelectorAll('.section-reveal');
      sections.forEach((section) => {
        const rect = section.getBoundingClientRect();
        if (rect.top < window.innerHeight - 100) {
          section.classList.add('visible');
        }
      });

      const stepCards = document.querySelectorAll('.step-card');
      stepCards.forEach((card, index) => {
        const rect = card.getBoundingClientRect();
        if (rect.top < window.innerHeight - 100) {
          setTimeout(() => {
            card.classList.add('visible');
          }, index * 150);
        }
      });
    };

    window.addEventListener('scroll', revealOnScroll);
    revealOnScroll();

    return () => window.removeEventListener('scroll', revealOnScroll);
  }, []);

  return (
    <div className="min-h-screen gradient-bg-animated overflow-hidden relative">
      {/* Floating Graphics */}
      {floatingGraphics.map((graphic, index) => {
        const Icon = graphic.icon;
        return (
          <div
            key={index}
            className={`hidden xl:block absolute ${graphic.position} floating-graphic`}
            style={{ animationDelay: graphic.delay }}
          >
            <Icon className="w-32 h-32 text-primary" strokeWidth={1} />
          </div>
        );
      })}

      {/* Floating Blobs */}
      <div className="floating-blob w-96 h-96 bg-primary/20 top-20 left-10"></div>
      <div className="floating-blob w-80 h-80 bg-secondary/15 bottom-20 right-20" style={{ animationDelay: '5s' }}></div>

      <div className="container mx-auto px-4 py-16 xl:py-24 page-load relative z-10">
        {/* Hero Section */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-12 items-center mb-20 xl:mb-28">
          <div className="text-center xl:text-left">
            <div className="inline-block mb-8">
              <div className="relative">
                <img 
                  src="https://miaoda-conversation-file.s3cdn.medo.dev/user-7ntwmnsoqqdc/conv-7nty0n8vrnr4/20251119/file-7nut03dw4d8g.jpg" 
                  alt="MINDZY Logo" 
                  className="w-28 h-28 xl:w-36 xl:h-36 mx-auto xl:mx-0 mb-6 zoom-in drop-shadow-2xl"
                />
                <div className="absolute inset-0 blur-3xl bg-primary/20 rounded-full -z-10"></div>
              </div>
              <h1 className="text-6xl xl:text-8xl font-bold logo-bubble mb-4">
                MINDZY
              </h1>
              <div className="h-1 bg-gradient-to-r from-transparent via-primary to-transparent rounded-full mx-auto xl:mx-0 w-48"></div>
            </div>
            <p className="text-2xl xl:text-3xl text-white/95 mb-6 max-w-3xl mx-auto xl:mx-0 font-bold tracking-tight">
              Your next big idea's just one prompt away
            </p>
            <p className="text-lg xl:text-xl text-white/60 mb-10 max-w-2xl mx-auto xl:mx-0 leading-relaxed">
              Enhance learning efficiency, master time management, and organize your studies with 11 integrated AI-powered tools
            </p>
            <Button
              size="lg"
              onClick={() => navigate('/dashboard')}
              className="btn-glow text-xl px-12 py-7 rounded-full font-bold shadow-2xl border-0"
            >
              Get Started →
            </Button>
          </div>

          {/* Hero Graphic */}
          <div className="relative hidden xl:block">
            <div className="floating-graphic">
              <img 
                src="https://miaoda-site-img.s3cdn.medo.dev/images/9060a453-6e5d-4b49-9581-a75606acdd71.jpg"
                alt="Student studying"
                className="w-full h-auto rounded-3xl shadow-2xl"
              />
            </div>
            <div className="absolute inset-0 blur-3xl bg-primary/10 rounded-full -z-10"></div>
          </div>
        </div>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8 xl:gap-10 max-w-7xl mx-auto mb-32">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="card-scroll card-3d p-8 xl:p-10 rounded-3xl group cursor-pointer"
                style={{ animationDelay: `${index * 0.15}s` }}
              >
                <div className="flex flex-col items-center text-center">
                  <div className="w-20 h-20 xl:w-24 xl:h-24 rounded-2xl bg-gradient-to-br from-primary/20 to-secondary/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                    <Icon className="w-10 h-10 xl:w-12 xl:h-12 text-primary drop-shadow-lg icon-pulse" strokeWidth={1.5} />
                  </div>
                  <h3 className="text-2xl xl:text-3xl font-bold mb-3 text-white">
                    {feature.title}
                  </h3>
                  <p className="text-white/60 text-lg leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* How It Works Section */}
        <div className="section-reveal mb-32">
          <div className="text-center mb-16">
            <h2 className="text-4xl xl:text-6xl font-bold text-white mb-4 text-glow">
              How MINDZY Works
            </h2>
            <div className="h-1 bg-gradient-to-r from-transparent via-primary to-transparent rounded-full mx-auto w-32 mb-6"></div>
            <p className="text-xl text-white/70 max-w-2xl mx-auto">
              Four simple steps to transform your study experience
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8 max-w-7xl mx-auto">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isExpanded = expandedCard === index;
              
              return (
                <div
                  key={index}
                  className={`step-card glassmorphism rounded-3xl relative overflow-hidden group cursor-pointer transition-all duration-500 ${
                    isExpanded ? 'md:col-span-2 xl:col-span-4 scale-105 z-50' : 'p-8'
                  }`}
                  onClick={() => setExpandedCard(isExpanded ? null : index)}
                >
                  {!isExpanded ? (
                    <>
                      <div className="absolute top-4 right-4 text-6xl font-bold text-primary/10">
                        {index + 1}
                      </div>
                      <div className="relative z-10">
                        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/30 to-secondary/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                          <Icon className="w-8 h-8 text-primary icon-pulse" strokeWidth={2} />
                        </div>
                        <h3 className="text-2xl font-bold text-white mb-3">
                          {step.title}
                        </h3>
                        <p className="text-white/60 leading-relaxed">
                          {step.description}
                        </p>
                      </div>
                      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    </>
                  ) : (
                    <div className="p-8 xl:p-12 animate-in fade-in zoom-in duration-500">
                      <div className="flex justify-between items-start mb-6">
                        <div className="flex items-center gap-4">
                          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary/30 to-secondary/20 flex items-center justify-center">
                            <Icon className="w-10 h-10 text-primary" strokeWidth={2} />
                          </div>
                          <div>
                            <div className="text-sm text-primary/60 font-semibold mb-1">Step {index + 1}</div>
                            <h3 className="text-3xl xl:text-4xl font-bold text-white">
                              {step.title}
                            </h3>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-white hover:bg-primary/20 rounded-full"
                          onClick={(e) => {
                            e.stopPropagation();
                            setExpandedCard(null);
                          }}
                        >
                          <X className="w-6 h-6" />
                        </Button>
                      </div>

                      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                        <div>
                          <p className="text-xl text-white/80 leading-relaxed mb-6">
                            {step.detailedDescription}
                          </p>
                          <div className="bg-primary/10 border border-primary/30 rounded-2xl p-6">
                            <p className="text-lg text-white/70 italic">
                              💡 {step.exampleText}
                            </p>
                          </div>
                        </div>
                        <div className="relative">
                          <img 
                            src={step.image}
                            alt={step.title}
                            className="w-full h-auto rounded-2xl shadow-2xl"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent rounded-2xl"></div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Our Vision Section */}
        <div className="section-reveal relative overflow-hidden rounded-3xl mb-20">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-secondary/10 to-accent/5"></div>
          <div className="relative z-10 grid grid-cols-1 xl:grid-cols-2 gap-12 p-12 xl:p-20 items-center">
            <div>
              <h2 className="text-4xl xl:text-6xl font-bold text-white mb-6 text-glow">
                Our Vision
              </h2>
              <div className="h-1 bg-gradient-to-r from-primary to-transparent rounded-full w-32 mb-8"></div>
              <p className="text-xl xl:text-2xl text-white/90 leading-relaxed mb-6">
                To build the smartest, simplest, and most creative student productivity platform — where planning, learning, and revision become effortless.
              </p>
              <p className="text-lg xl:text-xl text-white/70 leading-relaxed">
                MINDZY is designed to empower students with AI tools that save time, boost confidence, and unlock their full potential.
              </p>
            </div>
            <div className="relative">
              <div className="floating-graphic">
                <Rocket className="w-64 h-64 xl:w-80 xl:h-80 text-primary/30 mx-auto" strokeWidth={1} />
              </div>
              <div className="absolute inset-0 blur-3xl bg-primary/10 rounded-full"></div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-24 text-center">
          <p className="text-white/40 text-sm tracking-wider">
            2025 MINDZY
          </p>
        </div>
      </div>
    </div>
  );
}
