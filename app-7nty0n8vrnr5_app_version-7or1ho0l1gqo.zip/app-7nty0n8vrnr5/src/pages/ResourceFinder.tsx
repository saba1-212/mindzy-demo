import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Search, Youtube, FileText, BookOpen, List, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function ResourceFinder() {
  const navigate = useNavigate();
  const [topic, setTopic] = useState('');
  const [loading, setLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);

  const exampleResources = {
    videos: [
      { title: 'Introduction to Calculus - Complete Course', channel: 'Khan Academy', views: '2.5M views', url: '#' },
      { title: 'Calculus Basics Explained Simply', channel: 'Math Simplified', views: '1.2M views', url: '#' },
      { title: 'Advanced Calculus Techniques', channel: 'Professor Leonard', views: '890K views', url: '#' },
    ],
    articles: [
      { title: 'Understanding Derivatives: A Comprehensive Guide', source: 'Math Portal', date: '2024' },
      { title: 'Calculus Applications in Real World', source: 'Science Daily', date: '2024' },
      { title: 'Mastering Integration Techniques', source: 'Study.com', date: '2024' },
    ],
    notes: [
      { title: 'Calculus Cheat Sheet', pages: '12 pages', format: 'PDF' },
      { title: 'Derivative Rules Summary', pages: '8 pages', format: 'PDF' },
      { title: 'Integration Formulas', pages: '10 pages', format: 'PDF' },
    ],
    playlists: [
      { title: 'Complete Calculus Course', videos: '45 videos', duration: '18 hours' },
      { title: 'Calculus Problem Solving', videos: '30 videos', duration: '12 hours' },
      { title: 'Calculus Exam Preparation', videos: '25 videos', duration: '10 hours' },
    ],
  };

  const handleSearch = () => {
    if (!topic.trim()) return;
    setLoading(true);
    setShowResults(false);
    setTimeout(() => {
      setLoading(false);
      setShowResults(true);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 bg-card/95 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Resource Finder</h1>
              <p className="text-sm text-muted-foreground">Discover curated learning materials</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Card className="card-3d fade-in mb-8">
            <CardContent className="pt-6">
              <div className="flex gap-4">
                <Input
                  placeholder="Enter study topic (e.g., Calculus, Physics, Chemistry)"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  className="flex-1"
                />
                <Button onClick={handleSearch} disabled={loading} className="btn-glow">
                  {loading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      <Search className="w-5 h-5 mr-2" />
                      Search
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {showResults && (
            <div className="space-y-6">
              <Card className="card-3d fade-in">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Youtube className="w-6 h-6 text-primary" />
                    Most Viewed Videos
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {exampleResources.videos.map((video, index) => (
                      <div
                        key={index}
                        className="slide-in p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer"
                        style={{ animationDelay: `${index * 0.1}s` }}
                      >
                        <h4 className="font-semibold mb-1">{video.title}</h4>
                        <p className="text-sm text-muted-foreground">
                          {video.channel} • {video.views}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="card-3d fade-in" style={{ animationDelay: '0.3s' }}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="w-6 h-6 text-secondary" />
                    Relevant Articles
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {exampleResources.articles.map((article, index) => (
                      <div
                        key={index}
                        className="slide-in p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer"
                        style={{ animationDelay: `${(index + 3) * 0.1}s` }}
                      >
                        <h4 className="font-semibold mb-1">{article.title}</h4>
                        <p className="text-sm text-muted-foreground">
                          {article.source} • {article.date}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                <Card className="card-3d fade-in" style={{ animationDelay: '0.6s' }}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BookOpen className="w-6 h-6 text-accent" />
                      Study Notes
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {exampleResources.notes.map((note, index) => (
                        <div
                          key={index}
                          className="slide-in p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer"
                          style={{ animationDelay: `${(index + 6) * 0.1}s` }}
                        >
                          <h4 className="font-medium mb-1">{note.title}</h4>
                          <p className="text-sm text-muted-foreground">
                            {note.pages} • {note.format}
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="card-3d fade-in" style={{ animationDelay: '0.7s' }}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <List className="w-6 h-6 text-chart-1" />
                      Curated Playlists
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {exampleResources.playlists.map((playlist, index) => (
                        <div
                          key={index}
                          className="slide-in p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer"
                          style={{ animationDelay: `${(index + 9) * 0.1}s` }}
                        >
                          <h4 className="font-medium mb-1">{playlist.title}</h4>
                          <p className="text-sm text-muted-foreground">
                            {playlist.videos} • {playlist.duration}
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
