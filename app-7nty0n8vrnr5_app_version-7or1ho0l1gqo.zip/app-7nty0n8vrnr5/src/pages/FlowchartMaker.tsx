import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Plus, Trash2, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Node {
  id: number;
  text: string;
  x: number;
  y: number;
}

interface Connection {
  from: number;
  to: number;
}

export default function FlowchartMaker() {
  const navigate = useNavigate();
  const [topic, setTopic] = useState('');
  const [loading, setLoading] = useState(false);
  const [showFlowchart, setShowFlowchart] = useState(false);
  const [nodes, setNodes] = useState<Node[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [selectedNode, setSelectedNode] = useState<number | null>(null);
  const [draggedNode, setDraggedNode] = useState<number | null>(null);
  const [editingNode, setEditingNode] = useState<number | null>(null);

  const generateFlowchart = () => {
    setLoading(true);
    setShowFlowchart(false);
    setTimeout(() => {
      const exampleNodes: Node[] = [
        { id: 1, text: 'Start: Study Session', x: 400, y: 50 },
        { id: 2, text: 'Review Materials', x: 400, y: 150 },
        { id: 3, text: 'Understand Concepts?', x: 400, y: 250 },
        { id: 4, text: 'Practice Problems', x: 250, y: 350 },
        { id: 5, text: 'Seek Help', x: 550, y: 350 },
        { id: 6, text: 'Take Quiz', x: 400, y: 450 },
        { id: 7, text: 'End: Session Complete', x: 400, y: 550 },
      ];
      const exampleConnections: Connection[] = [
        { from: 1, to: 2 },
        { from: 2, to: 3 },
        { from: 3, to: 4 },
        { from: 3, to: 5 },
        { from: 4, to: 6 },
        { from: 5, to: 6 },
        { from: 6, to: 7 },
      ];
      setNodes(exampleNodes);
      setConnections(exampleConnections);
      setLoading(false);
      setShowFlowchart(true);
    }, 2000);
  };

  const handleNodeDragStart = (id: number) => {
    setDraggedNode(id);
  };

  const handleNodeDrag = (e: React.MouseEvent, id: number) => {
    if (draggedNode !== id) return;
    const rect = e.currentTarget.parentElement?.getBoundingClientRect();
    if (!rect) return;
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setNodes(nodes.map((node) => (node.id === id ? { ...node, x, y } : node)));
  };

  const handleNodeDragEnd = () => {
    setDraggedNode(null);
  };

  const handleNodeEdit = (id: number, text: string) => {
    setNodes(nodes.map((node) => (node.id === id ? { ...node, text } : node)));
  };

  const handleAddNode = () => {
    const newNode: Node = {
      id: Date.now(),
      text: 'New Node',
      x: 400,
      y: 100 + nodes.length * 50,
    };
    setNodes([...nodes, newNode]);
  };

  const handleDeleteNode = (id: number) => {
    setNodes(nodes.filter((node) => node.id !== id));
    setConnections(connections.filter((conn) => conn.from !== id && conn.to !== id));
  };

  const handleConnect = (fromId: number) => {
    if (selectedNode === null) {
      setSelectedNode(fromId);
    } else if (selectedNode !== fromId) {
      setConnections([...connections, { from: selectedNode, to: fromId }]);
      setSelectedNode(null);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 bg-card/95 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Flowchart Maker</h1>
              <p className="text-sm text-muted-foreground">Create and edit flowcharts</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <Card className="card-3d fade-in mb-6">
            <CardContent className="pt-6">
              <div className="flex gap-4">
                <Input
                  placeholder="Enter topic (e.g., Study Process, Problem Solving)"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && generateFlowchart()}
                  className="flex-1"
                />
                <Button onClick={generateFlowchart} disabled={loading} className="btn-glow">
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    'Generate Flowchart ✨'
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {showFlowchart && (
            <>
              <div className="mb-4 flex gap-2">
                <Button onClick={handleAddNode} variant="outline">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Node
                </Button>
                <div className="text-sm text-muted-foreground flex items-center">
                  {selectedNode ? 'Click another node to connect' : 'Click a node to start connecting'}
                </div>
              </div>

              <Card className="card-3d fade-in" style={{ animationDelay: '0.2s' }}>
                <CardHeader>
                  <CardTitle>Editable Flowchart</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="relative w-full h-[600px] bg-muted/20 rounded-lg overflow-hidden">
                    <svg className="absolute inset-0 w-full h-full pointer-events-none">
                      {connections.map((conn, index) => {
                        const fromNode = nodes.find((n) => n.id === conn.from);
                        const toNode = nodes.find((n) => n.id === conn.to);
                        if (!fromNode || !toNode) return null;
                        return (
                          <line
                            key={index}
                            x1={fromNode.x}
                            y1={fromNode.y + 20}
                            x2={toNode.x}
                            y2={toNode.y - 20}
                            stroke="hsl(var(--primary))"
                            strokeWidth="2"
                            markerEnd="url(#arrowhead)"
                          />
                        );
                      })}
                      <defs>
                        <marker
                          id="arrowhead"
                          markerWidth="10"
                          markerHeight="10"
                          refX="9"
                          refY="3"
                          orient="auto"
                        >
                          <polygon points="0 0, 10 3, 0 6" fill="hsl(var(--primary))" />
                        </marker>
                      </defs>
                    </svg>

                    {nodes.map((node, index) => (
                      <div
                        key={node.id}
                        className="zoom-in absolute"
                        style={{
                          left: node.x - 80,
                          top: node.y - 20,
                          animationDelay: `${index * 0.1}s`,
                        }}
                      >
                        <div
                          className={`w-40 px-4 py-2 rounded-lg bg-card border-2 cursor-move group ${
                            selectedNode === node.id ? 'border-primary' : 'border-border'
                          }`}
                          onMouseDown={() => handleNodeDragStart(node.id)}
                          onMouseMove={(e) => handleNodeDrag(e, node.id)}
                          onMouseUp={handleNodeDragEnd}
                          onClick={() => handleConnect(node.id)}
                        >
                          {editingNode === node.id ? (
                            <Input
                              value={node.text}
                              onChange={(e) => handleNodeEdit(node.id, e.target.value)}
                              onBlur={() => setEditingNode(null)}
                              onKeyDown={(e) => e.key === 'Enter' && setEditingNode(null)}
                              className="h-8 text-sm"
                              autoFocus
                            />
                          ) : (
                            <div
                              className="text-sm text-center"
                              onDoubleClick={() => setEditingNode(node.id)}
                            >
                              {node.text}
                            </div>
                          )}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="absolute -top-2 -right-2 w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteNode(node.id);
                            }}
                          >
                            <Trash2 className="w-3 h-3 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 text-sm text-muted-foreground">
                    <p>• Drag nodes to move them</p>
                    <p>• Double-click to edit text</p>
                    <p>• Click two nodes to connect them</p>
                    <p>• Hover and click X to delete</p>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
