import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, Play, Pause, RotateCcw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Timer() {
  const navigate = useNavigate();
  const [minutes, setMinutes] = useState(25);
  const [seconds, setSeconds] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [totalSeconds, setTotalSeconds] = useState(25 * 60);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isRunning && (minutes > 0 || seconds > 0)) {
      intervalRef.current = setInterval(() => {
        if (seconds === 0) {
          if (minutes === 0) {
            setIsRunning(false);
          } else {
            setMinutes(minutes - 1);
            setSeconds(59);
          }
        } else {
          setSeconds(seconds - 1);
        }
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning, minutes, seconds]);

  const handleStart = () => {
    setIsRunning(true);
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  const handleReset = () => {
    setIsRunning(false);
    setMinutes(Math.floor(totalSeconds / 60));
    setSeconds(totalSeconds % 60);
  };

  const handleSetTime = (mins: number) => {
    setIsRunning(false);
    setMinutes(mins);
    setSeconds(0);
    setTotalSeconds(mins * 60);
  };

  const currentSeconds = minutes * 60 + seconds;
  const progress = ((totalSeconds - currentSeconds) / totalSeconds) * 100;
  const circumference = 2 * Math.PI * 120;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 bg-card/95 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Focus Timer</h1>
              <p className="text-sm text-muted-foreground">Stay focused and productive</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <Card className="card-3d fade-in">
            <CardContent className="pt-8">
              <div className="flex flex-col items-center">
                <div className="relative w-64 h-64 xl:w-80 xl:h-80 mb-8">
                  <svg className="w-full h-full transform -rotate-90">
                    <circle
                      cx="50%"
                      cy="50%"
                      r="120"
                      stroke="hsl(var(--muted))"
                      strokeWidth="12"
                      fill="none"
                    />
                    <circle
                      cx="50%"
                      cy="50%"
                      r="120"
                      stroke="hsl(var(--primary))"
                      strokeWidth="12"
                      fill="none"
                      strokeDasharray={circumference}
                      strokeDashoffset={strokeDashoffset}
                      strokeLinecap="round"
                      className={`transition-all duration-1000 ${isRunning ? 'drop-shadow-[0_0_20px_hsl(var(--primary))]' : ''}`}
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <div className="text-6xl xl:text-7xl font-bold gradient-text">
                      {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
                    </div>
                    <div className="text-sm text-muted-foreground mt-2">
                      {isRunning ? 'Focus Time' : 'Ready to Start'}
                    </div>
                  </div>
                </div>

                <div className="flex gap-4 mb-8">
                  {!isRunning ? (
                    <Button
                      size="lg"
                      onClick={handleStart}
                      className="btn-glow w-32"
                    >
                      <Play className="w-5 h-5 mr-2" />
                      Start
                    </Button>
                  ) : (
                    <Button
                      size="lg"
                      onClick={handlePause}
                      variant="secondary"
                      className="w-32"
                    >
                      <Pause className="w-5 h-5 mr-2" />
                      Pause
                    </Button>
                  )}
                  <Button
                    size="lg"
                    onClick={handleReset}
                    variant="outline"
                    className="w-32"
                  >
                    <RotateCcw className="w-5 h-5 mr-2" />
                    Reset
                  </Button>
                </div>

                <div className="w-full border-t border-border pt-6">
                  <h3 className="text-lg font-semibold mb-4 text-center">Quick Presets</h3>
                  <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
                    {[
                      { label: '5 min', value: 5 },
                      { label: '15 min', value: 15 },
                      { label: '25 min', value: 25 },
                      { label: '45 min', value: 45 },
                    ].map((preset) => (
                      <Button
                        key={preset.value}
                        variant="outline"
                        onClick={() => handleSetTime(preset.value)}
                        className="hover:bg-primary/10"
                      >
                        {preset.label}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="w-full border-t border-border pt-6 mt-6">
                  <h3 className="text-lg font-semibold mb-4 text-center">Custom Time</h3>
                  <div className="flex gap-4 items-center justify-center">
                    <Input
                      type="number"
                      min="1"
                      max="120"
                      placeholder="Minutes"
                      className="w-32"
                      onChange={(e) => {
                        const value = Number.parseInt(e.target.value) || 0;
                        if (value > 0) handleSetTime(value);
                      }}
                    />
                    <span className="text-muted-foreground">minutes</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
