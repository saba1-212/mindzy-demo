import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function StudyPlanner() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [showTimetable, setShowTimetable] = useState(false);
  const [formData, setFormData] = useState({
    studyHours: '',
    subjects: '',
    difficulty: '',
    deadline: '',
  });

  const exampleTimetable = [
    { day: 'Monday', subject: 'Mathematics', duration: '2 hours', time: '9:00 AM - 11:00 AM', color: 'bg-primary' },
    { day: 'Monday', subject: 'Physics', duration: '1.5 hours', time: '2:00 PM - 3:30 PM', color: 'bg-secondary' },
    { day: 'Tuesday', subject: 'Chemistry', duration: '2 hours', time: '10:00 AM - 12:00 PM', color: 'bg-accent' },
    { day: 'Tuesday', subject: 'English', duration: '1 hour', time: '3:00 PM - 4:00 PM', color: 'bg-chart-1' },
    { day: 'Wednesday', subject: 'Mathematics', duration: '2 hours', time: '9:00 AM - 11:00 AM', color: 'bg-primary' },
    { day: 'Wednesday', subject: 'History', duration: '1.5 hours', time: '1:00 PM - 2:30 PM', color: 'bg-chart-2' },
    { day: 'Thursday', subject: 'Physics', duration: '2 hours', time: '10:00 AM - 12:00 PM', color: 'bg-secondary' },
    { day: 'Thursday', subject: 'Chemistry', duration: '1 hour', time: '2:00 PM - 3:00 PM', color: 'bg-accent' },
    { day: 'Friday', subject: 'English', duration: '2 hours', time: '9:00 AM - 11:00 AM', color: 'bg-chart-1' },
    { day: 'Friday', subject: 'Review Session', duration: '1.5 hours', time: '3:00 PM - 4:30 PM', color: 'bg-chart-3' },
  ];

  const handleGenerate = () => {
    setLoading(true);
    setShowTimetable(false);
    setTimeout(() => {
      setLoading(false);
      setShowTimetable(true);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 bg-card/95 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Study Planner</h1>
              <p className="text-sm text-muted-foreground">AI-powered timetable generator</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Card className="card-3d fade-in mb-8">
            <CardHeader>
              <CardTitle>Generate Your Study Timetable</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="studyHours">Study Hours per Day</Label>
                  <Input
                    id="studyHours"
                    type="number"
                    placeholder="e.g., 6"
                    value={formData.studyHours}
                    onChange={(e) => setFormData({ ...formData, studyHours: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="subjects">Subjects (comma-separated)</Label>
                  <Input
                    id="subjects"
                    placeholder="e.g., Math, Physics, Chemistry"
                    value={formData.subjects}
                    onChange={(e) => setFormData({ ...formData, subjects: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="difficulty">Difficulty Level</Label>
                  <Select value={formData.difficulty} onValueChange={(value) => setFormData({ ...formData, difficulty: value })}>
                    <SelectTrigger id="difficulty">
                      <SelectValue placeholder="Select difficulty" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="easy">Easy</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="hard">Hard</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="deadline">Deadline</Label>
                  <Input
                    id="deadline"
                    type="date"
                    value={formData.deadline}
                    onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                  />
                </div>
              </div>

              <Button
                className="w-full btn-glow"
                size="lg"
                onClick={handleGenerate}
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Generating Your Timetable...
                  </>
                ) : (
                  'Generate Timetable ✨'
                )}
              </Button>
            </CardContent>
          </Card>

          {showTimetable && (
            <Card className="card-3d fade-in">
              <CardHeader>
                <CardTitle>Your Personalized Study Timetable</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {exampleTimetable.map((item, index) => (
                    <div
                      key={index}
                      className="slide-in"
                      style={{ animationDelay: `${index * 0.1}s` }}
                    >
                      <div className={`${item.color}/10 border-l-4 ${item.color.replace('bg-', 'border-')} p-4 rounded-lg`}>
                        <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-2">
                          <div className="flex items-center gap-4">
                            <div className="font-semibold text-foreground min-w-24">
                              {item.day}
                            </div>
                            <div className="font-medium text-lg">{item.subject}</div>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span>{item.time}</span>
                            <span className="font-medium">{item.duration}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
