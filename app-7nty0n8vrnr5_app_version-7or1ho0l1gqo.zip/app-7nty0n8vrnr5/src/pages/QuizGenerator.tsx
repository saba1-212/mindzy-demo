import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Loader2, CheckCircle2, XCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  revealed: boolean;
  selectedAnswer: number | null;
}

export default function QuizGenerator() {
  const navigate = useNavigate();
  const [topic, setTopic] = useState('');
  const [loading, setLoading] = useState(false);
  const [showQuiz, setShowQuiz] = useState(false);
  const [questions, setQuestions] = useState<Question[]>([]);

  const generateQuiz = () => {
    if (!topic.trim()) return;
    setLoading(true);
    setShowQuiz(false);
    setTimeout(() => {
      const exampleQuestions: Question[] = [
        {
          id: 1,
          question: 'What is the derivative of x²?',
          options: ['x', '2x', 'x²', '2'],
          correctAnswer: 1,
          revealed: false,
          selectedAnswer: null,
        },
        {
          id: 2,
          question: 'What is the integral of 1/x?',
          options: ['x²', 'ln|x| + C', '1/x²', 'e^x'],
          correctAnswer: 1,
          revealed: false,
          selectedAnswer: null,
        },
        {
          id: 3,
          question: 'What is the limit of (sin x)/x as x approaches 0?',
          options: ['0', '1', '∞', 'undefined'],
          correctAnswer: 1,
          revealed: false,
          selectedAnswer: null,
        },
        {
          id: 4,
          question: 'What is the chain rule used for?',
          options: [
            'Adding functions',
            'Multiplying functions',
            'Differentiating composite functions',
            'Integrating functions',
          ],
          correctAnswer: 2,
          revealed: false,
          selectedAnswer: null,
        },
        {
          id: 5,
          question: 'What is e^(ln x)?',
          options: ['1', 'x', 'ln x', 'e'],
          correctAnswer: 1,
          revealed: false,
          selectedAnswer: null,
        },
      ];
      setQuestions(exampleQuestions);
      setLoading(false);
      setShowQuiz(true);
    }, 2000);
  };

  const handleSelectAnswer = (questionId: number, answerIndex: number) => {
    setQuestions(
      questions.map((q) =>
        q.id === questionId ? { ...q, selectedAnswer: answerIndex } : q
      )
    );
  };

  const handleReveal = (questionId: number) => {
    setQuestions(
      questions.map((q) => (q.id === questionId ? { ...q, revealed: true } : q))
    );
  };

  const calculateScore = () => {
    const answered = questions.filter((q) => q.selectedAnswer !== null);
    const correct = answered.filter((q) => q.selectedAnswer === q.correctAnswer);
    return { correct: correct.length, total: answered.length };
  };

  const score = calculateScore();

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 bg-card/95 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Quiz Generator</h1>
              <p className="text-sm text-muted-foreground">Test your knowledge</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Card className="card-3d fade-in mb-8">
            <CardContent className="pt-6">
              <div className="flex gap-4">
                <Input
                  placeholder="Enter topic (e.g., Calculus, Physics, Chemistry)"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && generateQuiz()}
                  className="flex-1"
                />
                <Button onClick={generateQuiz} disabled={loading} className="btn-glow">
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    'Generate Quiz ✨'
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {showQuiz && (
            <>
              {score.total > 0 && (
                <Card className="card-3d fade-in mb-6">
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className="text-4xl font-bold gradient-text mb-2">
                        {score.correct} / {score.total}
                      </div>
                      <div className="text-muted-foreground">
                        {score.total === questions.length
                          ? `Final Score: ${Math.round((score.correct / score.total) * 100)}%`
                          : 'Current Progress'}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="space-y-6">
                {questions.map((question, index) => (
                  <Card
                    key={question.id}
                    className="card-3d zoom-in"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <CardHeader>
                      <CardTitle className="text-lg">
                        Question {index + 1}: {question.question}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="space-y-2">
                        {question.options.map((option, optionIndex) => {
                          const isSelected = question.selectedAnswer === optionIndex;
                          const isCorrect = question.correctAnswer === optionIndex;
                          const showResult = question.revealed;

                          return (
                            <button
                              key={optionIndex}
                              onClick={() => handleSelectAnswer(question.id, optionIndex)}
                              disabled={question.revealed}
                              className={`w-full p-4 rounded-lg text-left transition-all ${
                                showResult
                                  ? isCorrect
                                    ? 'bg-primary/20 border-2 border-primary'
                                    : isSelected
                                      ? 'bg-destructive/20 border-2 border-destructive'
                                      : 'bg-muted/50'
                                  : isSelected
                                    ? 'bg-primary/10 border-2 border-primary'
                                    : 'bg-muted/50 hover:bg-muted'
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <span>{option}</span>
                                {showResult && isCorrect && (
                                  <CheckCircle2 className="w-5 h-5 text-primary" />
                                )}
                                {showResult && isSelected && !isCorrect && (
                                  <XCircle className="w-5 h-5 text-destructive" />
                                )}
                              </div>
                            </button>
                          );
                        })}
                      </div>

                      {!question.revealed && question.selectedAnswer !== null && (
                        <Button
                          onClick={() => handleReveal(question.id)}
                          className="w-full"
                          variant="outline"
                        >
                          Reveal Answer
                        </Button>
                      )}

                      {question.revealed && (
                        <div
                          className={`p-4 rounded-lg ${
                            question.selectedAnswer === question.correctAnswer
                              ? 'bg-primary/10 text-primary'
                              : 'bg-destructive/10 text-destructive'
                          }`}
                        >
                          {question.selectedAnswer === question.correctAnswer
                            ? '✓ Correct! Well done!'
                            : `✗ Incorrect. The correct answer is: ${question.options[question.correctAnswer]}`}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
